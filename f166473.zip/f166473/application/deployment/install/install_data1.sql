prompt --application/deployment/install/install_data1
begin
--   Manifest
--     INSTALL: INSTALL-data1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(69059035807661762716)
,p_install_id=>wwv_flow_imp.id(66372101294642118547)
,p_name=>'data1'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --T_USERS: 2/10000 rows exported, APEX$DATA$PKG/T_USERS$411160',
'    apex_data_install.load_supporting_object_data(p_table_name => ''T_USERS'', p_delete_after_install => true );',
'',
'',
'   update T_USERS set PASSWORD = FN_HASH_PASSWORD(UPPER(''admin''), ''123456'')  where lower(username) = ''admin'';',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
