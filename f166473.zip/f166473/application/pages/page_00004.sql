prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'change-password'
,p_alias=>'CHANGE-PASSWORD'
,p_step_title=>'change-password'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66133716929990250703)
,p_plug_name=>'change password'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66133717404913250708)
,p_plug_name=>'buttons'
,p_parent_plug_id=>wwv_flow_imp.id(66133716929990250703)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66138282852245554286)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--slimPadding:t-ButtonRegion--noUI'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(65949116677151674846)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(66133717508200250709)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(66133717404913250708)
,p_button_name=>'submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(66369644599993048366)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(67411833701388179318)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(66133717404913250708)
,p_button_name=>'back'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Back'
,p_button_position=>'EDIT'
,p_icon_css_classes=>'fa-redo-arrow'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(66133717951421250713)
,p_branch_name=>'redirect to home'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66133717023476250704)
,p_name=>'P4_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(66133716929990250703)
,p_item_default=>':APP_USER'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66133717191321250705)
,p_name=>'P4_CURRENTPASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(66133716929990250703)
,p_prompt=>'Currentpassword'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66133717280265250706)
,p_name=>'P4_NEWPASSWORD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(66133716929990250703)
,p_prompt=>'Newpassword'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66133717396149250707)
,p_name=>'P4_CONFIRMPASSWORD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(66133716929990250703)
,p_prompt=>'Confirmpassword'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(66133717628703250710)
,p_validation_name=>'old-pass'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_pass VARCHAR2(200);',
'BEGIN',
'    SELECT password ',
'    INTO l_pass ',
'    FROM t_users ',
'    WHERE username = :P4_USERNAME;',
'',
'    IF FN_HASH_PASSWORD(UPPER(:P4_USERNAME), :P4_CURRENTPASSWORD) != l_pass THEN',
'        RETURN ''Current password is incorrect.'';',
'    END IF;',
'',
'    RETURN NULL;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(66133717744545250711)
,p_validation_name=>'New-pass'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_pass VARCHAR2(200);',
'BEGIN',
'    IF LENGTH(:P4_NEWPASSWORD) < 8 THEN',
'        RETURN ''Password must be at least 8 characters long.'';',
'    END IF;',
'',
'    IF :P4_NEWPASSWORD != :P4_CONFIRMPASSWORD THEN',
'        RETURN ''New password and confirmation do not match.'';',
'    END IF;',
'',
'    RETURN NULL;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(66133717854040250712)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'submit process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update T_USERS',
'set  password  = FN_HASH_PASSWORD( upper(:P4_USERNAME) , :P4_NEWPASSWORD)   , MUST_CHANGE_PW = ''N''',
'where USERNAME = :P4_USERNAME;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>66133717854040250712
);
wwv_flow_imp.component_end;
end;
/
