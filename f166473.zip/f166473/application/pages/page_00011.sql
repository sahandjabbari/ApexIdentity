prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'role-permissions'
,p_alias=>'ROLE-PERMISSIONS'
,p_step_title=>'role permissions'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66374023804431205623)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--slimPadding:t-ButtonRegion--noUI'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(65949116677151674846)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66374024523472205625)
,p_plug_name=>'role-permissions'
,p_region_name=>'grid1'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ROWID,',
'       ID,',
'       PID,',
'       ROLE_ID,',
'       COMPONENTID, ',
'       VISIBLE_',
'  from T_ROLE_PERMISSIONS  d where Role_Id= :P11_ROLEID',
'     AND (COMPONENTID=:P11_SELECTEDNODE or pid=:P11_SELECTEDNODE )',
'   '))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P11_ROLEID,P11_SELECTEDNODE'
,p_prn_page_header=>'role-permissions'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(66133718232255250716)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(66133718369345250717)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(66374025868719205629)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(66374026842392205631)
,p_name=>'ROLE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROLE_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(66374027873888205632)
,p_name=>'COMPONENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPONENTID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Componentid'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_is_required=>true
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>' select ttl || ''-'' || id , id  from VW_ALLCONTROLS where app_id1 = :app_id'
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(66374028806914205632)
,p_name=>'VISIBLE_'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VISIBLE_'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Visible '
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(66374029821608205633)
,p_name=>'Parent Item'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Pid'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>' select ttl || ''-'' || id , id  from VW_ALLCONTROLS where app_id1 = :app_id'
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(67411833637706179317)
,p_name=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROWID'
,p_data_type=>'ROWID'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(66374025074348205627)
,p_internal_uid=>66374025074348205627
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(66374025424783205627)
,p_interactive_grid_id=>wwv_flow_imp.id(66374025074348205627)
,p_static_id=>'663740255'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>1000
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(66374025626269205627)
,p_report_id=>wwv_flow_imp.id(66374025424783205627)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(66374026213243205630)
,p_view_id=>wwv_flow_imp.id(66374025626269205627)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(66374025868719205629)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(66374027211231205631)
,p_view_id=>wwv_flow_imp.id(66374025626269205627)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(66374026842392205631)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(66374028215840205632)
,p_view_id=>wwv_flow_imp.id(66374025626269205627)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(66374027873888205632)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(66374029218723205633)
,p_view_id=>wwv_flow_imp.id(66374025626269205627)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(66374028806914205632)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(66374030252414205634)
,p_view_id=>wwv_flow_imp.id(66374025626269205627)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(66374029821608205633)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(66374071534036210394)
,p_view_id=>wwv_flow_imp.id(66374025626269205627)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(66133718232255250716)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(67483821293137466439)
,p_view_id=>wwv_flow_imp.id(66374025626269205627)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(67411833637706179317)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(67411833067221179311)
,p_plug_name=>'tree'
,p_region_name=>'tree1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT distinct',
'      a.id , ',
'      a.pid PARENT_ID,',
'       a.ttl   AS TITLE, ',
'     cast(a.id as number(20,0))  AS VALUE',
'    ,a.app_id1',
'        ,  ''javascript:$s(''''P11_SELECTEDNODE'''', ''''''||a.ID||'''''');'' as link',
'',
'  FROM',
'     VW_ALLCONTROLS a',
'     left join T_ROLE_PERMISSIONS rc on a.id = rc.componentid  ',
'     left join T_USER_ROLES ur on rc.role_id= ur.role_id and ur.role_id=:P11_ROLEID  ',
'     where a.app_id1 = :app_id',
'   '))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_ajax_items_to_submit=>'P11_ROLEID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_type_css_class', 'a-Icon',
  'link_column', 'LINK',
  'node_id_column', 'ID',
  'node_label_column', 'TITLE',
  'parent_key_column', 'PARENT_ID',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(66133719536506250729)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(66374024523472205625)
,p_button_name=>'back'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Back'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(66133719685645250730)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(66374024523472205625)
,p_button_name=>'copyrole'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Copy Role'
,p_button_position=>'PREVIOUS'
,p_confirm_message=>'Are you sure?'
,p_confirm_style=>'warning'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(66133720084196250734)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(66374024523472205625)
,p_button_name=>'delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'PREVIOUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66133718587474250719)
,p_name=>'P11_ROLEID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(67411833067221179311)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66133719216995250726)
,p_name=>'P11_TREEFILTER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(67411833067221179311)
,p_prompt=>'Tree filter'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(67411833165273179312)
,p_name=>'P11_SELECTEDNODE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(67411833067221179311)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(67411833372083179314)
,p_name=>'P11_ROLENAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(66374024523472205625)
,p_prompt=>'Rolename'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(67411833492668179315)
,p_name=>'onChange'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P11_SELECTEDNODE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(67411833532771179316)
,p_event_id=>wwv_flow_imp.id(67411833492668179315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(66374024523472205625)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(66133719090562250724)
,p_name=>'grid-onChange'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(66374024523472205625)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(66133719175554250725)
,p_event_id=>wwv_flow_imp.id(66133719090562250724)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region("grid1").widget().interactiveGrid("getActions").invoke("save");',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(66133719336237250727)
,p_name=>'tree filter change'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P11_TREEFILTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(66133719457346250728)
,p_event_id=>wwv_flow_imp.id(66133719336237250727)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' function filterTree(){',
'    var q = apex.item(''P11_TREEFILTER'').getValue() ;',
'console.log(q)',
'    var nodes = document.querySelectorAll(''#tree1 .a-TreeView-node'');',
'',
'    nodes.forEach(function(node){   ',
'',
'                var text = node.textContent.toLowerCase();',
'                if(text.includes(q)){',
'                    node.closest(''li'').style.display = '''';',
'                    showParents(node)',
'                }else',
'                {',
'                    node.closest(''li'').style.display = ''none'';',
'                }',
'    });',
'}',
'',
'//-------------------------------------------------------',
'function showParents(node){',
'  var parent = node.closest(''li'').parentElement.closest(''li'');',
'  if(parent){',
'    parent.style.display = '''';',
'    showParents(parent)',
'  }',
'}',
'',
'filterTree();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(66133719844947250732)
,p_name=>'onLoad'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(66133719947890250733)
,p_event_id=>wwv_flow_imp.id(66133719844947250732)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'INSERT INTO T_ROLE_PERMISSIONS (',
'    ROLE_ID,',
'    COMPONENTID,',
'    VISIBLE_,',
'    PID',
')',
'SELECT',
'    :P11_ROLEID,',
'    ID,',
'    ''N'',',
'    PID',
'FROM',
'    VW_ALLCONTROLS A',
'WHERE',
'    APP_ID1 = :APP_ID',
'    AND ID NOT IN (',
'        SELECT COMPONENTID',
'        FROM T_ROLE_PERMISSIONS',
'        WHERE ROLE_ID = :P11_ROLEID',
'    );',
''))
,p_attribute_02=>'P11_ROLEID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(66133718424896250718)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(66374024523472205625)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'role-permissions - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>66133718424896250718
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(66133719763455250731)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'copy process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l_id number;',
'l_ROLE_NAME nvarchar2(100);',
'l_appid  varchar2(10);',
'',
'begin',
'',
'',
'select ROLENAME  ',
' into l_ROLE_NAME ',
' from T_ROLES where id= :P11_ROLEID ;',
'',
'insert into T_ROLES( ROLENAME )',
'values( '' copy of '' || l_ROLE_NAME )',
'       returning id into l_id  ;',
'',
'',
'',
'  insert into T_ROLE_PERMISSIONS( ROLE_ID,',
'         COMPONENTID,',
'         VISIBLE_,',
'         PID)',
'  select  distinct',
'         l_id,',
'         COMPONENTID,',
'         VISIBLE_,',
'        PID',
'  from T_ROLE_PERMISSIONS a where role_id = :P11_ROLEID;',
'',
'commit ;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(66133719685645250730)
,p_internal_uid=>66133719763455250731
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(66133720123374250735)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'delete process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete T_ROLE_PERMISSIONS where role_id = :P87_MAIN_ROLE_ID;',
'commit;',
'delete T_ROLEs where id = :P87_MAIN_ROLE_ID;',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(66133720084196250734)
,p_internal_uid=>66133720123374250735
);
wwv_flow_imp.component_end;
end;
/
