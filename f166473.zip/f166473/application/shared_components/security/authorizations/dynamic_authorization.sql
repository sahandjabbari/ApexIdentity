prompt --application/shared_components/security/authorizations/dynamic_authorization
begin
--   Manifest
--     SECURITY SCHEME: dynamic authorization
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(66369644599993048366)
,p_name=>'dynamic authorization'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE L_EXISTS  NUMBER :=0 ;',
'begin',
'  ',
'',
'IF LOWER(APEX_UTIL.GET_SESSION_STATE(''SESSION_USER_NAME'')) = ''admin'' THEN',
'RETURN true;',
' ',
'END IF;',
' ',
'',
'IF :APP_COMPONENT_TYPE = ''APEX_APPLICATION_PAGES'' THEN',
'',
'SELECT COUNT(*) INTO L_EXISTS  FROM T_ROLE_PERMISSIONS RP',
'INNER JOIN T_USER_ROLES UR ON RP.ROLE_ID = UR.ROLE_ID',
'LEFT JOIN VW_ALLCONTROLS AC ON RP.COMPONENTID = AC.ID',
'WHERE UR.USER_ID  = APEX_UTIL.GET_SESSION_STATE(''SESSION_USER_ID'')',
'AND  COMPONENTID  = :APP_PAGE_ID AND TP= ''page'' and VISIBLE_ = ''Y'' ;',
' ',
'END IF;',
'',
'',
'',
'IF :APP_COMPONENT_TYPE = ''APEX_APPLICATION_LIST_ENTRIES'' THEN',
'',
'SELECT COUNT(*) INTO L_EXISTS  FROM T_ROLE_PERMISSIONS RP',
'INNER JOIN T_USER_ROLES UR ON RP.ROLE_ID = UR.ROLE_ID',
'LEFT JOIN VW_ALLCONTROLS AC ON RP.COMPONENTID = AC.ID',
'WHERE UR.USER_ID  = APEX_UTIL.GET_SESSION_STATE(''SESSION_USER_ID'')',
'AND  COMPONENTID  = :APP_COMPONENT_ID AND TP= ''menu'' and VISIBLE_ = ''Y'' ;',
' ',
'END IF;',
' ',
'',
'IF :APP_COMPONENT_TYPE = ''APEX_APPLICATION_PAGE_REGIONS'' THEN',
'',
'SELECT COUNT(*) INTO L_EXISTS  FROM T_ROLE_PERMISSIONS RP',
'INNER JOIN T_USER_ROLES UR ON RP.ROLE_ID = UR.ROLE_ID',
'LEFT JOIN VW_ALLCONTROLS AC ON RP.COMPONENTID = AC.ID',
'WHERE UR.USER_ID  = APEX_UTIL.GET_SESSION_STATE(''SESSION_USER_ID'')',
'AND  COMPONENTID  = :APP_COMPONENT_ID AND TP= ''region'' and VISIBLE_ = ''Y'' ;',
' ',
'END IF;',
' ',
'',
'',
'',
'IF :APP_COMPONENT_TYPE = ''APEX_APPLICATION_BUTTONS'' THEN',
' ',
'SELECT COUNT(*) INTO L_EXISTS  FROM T_ROLE_PERMISSIONS RP',
'INNER JOIN T_USER_ROLES UR ON RP.ROLE_ID = UR.ROLE_ID',
'LEFT JOIN VW_ALLCONTROLS AC ON RP.COMPONENTID = AC.ID',
'WHERE UR.USER_ID  = APEX_UTIL.GET_SESSION_STATE(''SESSION_USER_ID'')',
'AND  COMPONENTID  = :APP_COMPONENT_ID AND TP= ''button'' and VISIBLE_ = ''Y'' ;',
' ',
'END IF;',
'',
'',
'',
'IF L_EXISTS >0 THEN',
'RETURN true;',
'ELSE',
'RETURN FALSE;',
'END IF; ',
'',
'exception WHEN NO_DATA_FOUND THEN',
'RETURN FALSE;',
'end;'))
,p_version_scn=>15640739998516
,p_caching=>'NOCACHE'
);
wwv_flow_imp.component_end;
end;
/
