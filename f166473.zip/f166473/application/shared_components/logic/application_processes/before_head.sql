prompt --application/shared_components/logic/application_processes/before_head
begin
--   Manifest
--     APPLICATION PROCESS: before head
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(66993321974979562182)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'before head'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_all_info CLOB := '''';',
'BEGIN',
'  prc_log_user_activity (',
'    p_username     => :APP_USER,',
'    p_action_type  => ''SHOW'',',
'    p_page_id      => :APP_PAGE_ID,',
'    p_process_name => ''SHOW'',',
'    p_form_data    => null,',
'    p_ip_address   => owa_util.get_cgi_env(''REMOTE_ADDR''),',
'    p_user_agent   => owa_util.get_cgi_env(''HTTP_USER_AGENT''),',
'    p_session_id   => :APP_SESSION,',
'    p_app_id       => :APP_ID,',
'    p_table_name   => '''', ',
'    p_table_key    => null,',
'    p_page_title   =>   OWA_UTIL.GET_CGI_ENV(''REQUEST_URI''),',
'    p_request_method =>  ''GET'',',
'    p_request_url  =>   OWA_UTIL.GET_CGI_ENV(''PATH_INFO''),',
'    p_notes        =>  null',
'  );',
'',
' ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>15641260510668
);
wwv_flow_imp.component_end;
end;
/
