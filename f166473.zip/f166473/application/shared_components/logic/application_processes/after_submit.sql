prompt --application/shared_components/logic/application_processes/after_submit
begin
--   Manifest
--     APPLICATION PROCESS: after submit
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(66992862091748520436)
,p_process_sequence=>1
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'after submit'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json  CLOB := ''{'';',
'    l_value VARCHAR2(4000);',
'    l_count INTEGER := 0;',
'BEGIN',
' ',
'    FOR rec IN (',
'        SELECT item_name',
'        FROM apex_application_page_items',
'        WHERE application_id = :APP_ID',
'          AND page_id = :APP_PAGE_ID',
'          AND display_as_code != ''NATIVE_PASSWORD''  ',
'',
'    ) LOOP',
' ',
'        l_value := apex_util.get_session_state(rec.item_name);',
'',
'        IF l_value IS NOT NULL THEN',
'            l_json := l_json || ''"'' || rec.item_name || ''":"'' || REPLACE(l_value, ''"'', ''\"'') || ''",'';',
'            l_count := l_count + 1;',
'        END IF;',
'    END LOOP;',
'',
unistr('    -- \062D\0630\0641 \0648 \0628\0633\062A\0646'),
'    IF l_count > 0 THEN',
'        l_json := RTRIM(l_json, '','') || ''}'';',
'    ELSE',
'        l_json := ''{}'';',
'    END IF;',
' ',
' ',
'    prc_log_user_activity (',
'      p_username     => :APP_USER,',
'      p_action_type  => :REQUEST,',
'      p_page_id      => :APP_PAGE_ID,',
'      p_process_name => ''SUBMIT FORM'',',
'      p_form_data    => l_json,',
'      p_ip_address   => owa_util.get_cgi_env(''REMOTE_ADDR''),',
'      p_user_agent   => owa_util.get_cgi_env(''HTTP_USER_AGENT''),',
'      p_session_id   => :APP_SESSION,',
'      p_app_id       => :APP_ID,',
'      p_table_name   => '''', ',
'      p_table_key    => NULL,',
'      p_page_title   => NULL,',
'      p_request_method => OWA_UTIL.GET_CGI_ENV(''REQUEST_METHOD''),',
'      p_request_url  =>   OWA_UTIL.GET_CGI_ENV(''PATH_INFO''),',
'      p_notes        => NULL',
'    );',
'',
' ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_version_scn=>15641260251707
);
wwv_flow_imp.component_end;
end;
/
