prompt --application/shared_components/logic/application_processes/check_change_pass
begin
--   Manifest
--     APPLICATION PROCESS: check change pass
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(66993552981465543886)
,p_process_sequence=>1
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'check change pass'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_must_change varchar2(1);',
'        page_name varchar2(200);',
'        l_PASSWORD_EXPIRY_DATE date;',
'        l_SESSION_SEC_QUES_COMPLETE varchar2(10);',
'        l_sec_ques_enable varchar2(10) := ''N'';',
'begin',
'null;',
'   -- if  :APP_PAGE_ID not in(''9999'', ''89'' , ''4'' , ''8'' , ''9'') then',
'',
'',
'      ',
'',
'',
'        -- begin',
'        -- SELECT nvl(must_change_pw , ''N'' ) , nvl(PASSWORD_EXPIRY_DATE , sysdate -1 ) INTO v_must_change , l_PASSWORD_EXPIRY_DATE',
'        -- FROM t_users',
'        -- WHERE id = apex_util.get_session_state(''SESSION_USER_ID'');-- :APP_USER;',
'        -- exception when no_data_found then',
'        --     v_must_change := ''N'';',
'        -- end;',
'',
'        -- if l_PASSWORD_EXPIRY_DATE < sysdate+1 then',
'        --      APEX_UTIL.REDIRECT_URL(  ''/ords/r/ws_superv/superv/change-password?session=''||  v(''APP_SESSION'')|| '''');',
'        -- end if;',
'',
'        -- SELECT page_name  into page_name',
'        -- FROM apex_application_pages ',
'        -- WHERE application_id = :APP_ID ',
'        -- AND page_id = :APP_PAGE_ID;',
'',
'        -- if v_must_change = ''Y'' then',
'        --      APEX_UTIL.REDIRECT_URL(  ''/ords/r/ws_superv/superv/change-password?session=''||  v(''APP_SESSION'')|| '''');',
'        -- end if;    ',
'',
'',
'        --   for i in(select ITEMVALUE from T_CONFIG where ITEMKEY = ''SecurityQuestionsEnable'' )loop',
'        --     l_sec_ques_enable := nvl(i.ITEMVALUE, ''N'') ;',
'        -- end loop;',
'',
'',
'        --   l_SESSION_SEC_QUES_COMPLETE := apex_util.get_session_state(''SESSION_SEC_QUES_COMPLETE'');',
'',
'        -- if  nvl(l_SESSION_SEC_QUES_COMPLETE,''Y'') = ''N'' and l_sec_ques_enable = ''Y''   then',
'        --       APEX_UTIL.REDIRECT_URL(  ''/ords/r/ws_superv/superv/security-question-page?session=''||  v(''APP_SESSION'')|| '''');',
'        -- end if;',
'',
'--end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>15641260693673
);
wwv_flow_imp.component_end;
end;
/
