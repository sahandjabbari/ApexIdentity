prompt --application/shared_components/logic/application_processes/after_login
begin
--   Manifest
--     APPLICATION PROCESS: after login
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(66997397038330676021)
,p_process_sequence=>1
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'after login'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_token           VARCHAR2 (4000);',
'    l_is_user_exists  NUMBER;',
'    l_username        VARCHAR2(200);',
'    l_user_role       VARCHAR2(200);',
'    l_ques1           number; ',
'    l_ques2           number;  ',
'    l_answ1           nvarchar2(100);  ',
'    l_answ2           nvarchar2(100);',
'BEGIN',
'null;',
'    --check if the user exists in our app_users where the username is ',
'    --equal to the name passed with the request.',
'   /* SELECT COUNT (*)',
'      INTO l_is_user_exists',
'      FROM T_USERS',
'     WHERE LOWER(USER_NAME) = LOWER(:APP_USER);',
'    --if the user does not exist in our table, return an error message',
'    --in a json format',
'    IF l_is_user_exists <= 0',
'    THEN',
'        APEX_JSON.open_object;',
'        APEX_JSON.write (''message'', ''User doesnt exist'');',
'        APEX_JSON.close_object;',
'        RETURN;',
'    END IF;',
'    --if the user exists, get the username and user role from the table.',
'    SELECT USER_NAME ,SECURITY_QUESTION_1 ,SECURITY_QUESTION_2 ,SECURITY_ANSWER_1 , SECURITY_ANSWER_2',
'      INTO l_username ,l_ques1 ,l_ques2 , l_answ1 , l_answ2',
'      FROM T_USERS',
'     WHERE LOWER(USER_NAME) = LOWER(:APP_USER);',
'     ',
'',
'     if l_answ1 is null  or l_answ2 is null or l_ques1 is null or l_ques2 is null then',
'        apex_util.set_session_state(''SESSION_SEC_QUES_COMPLETE'', ''N'');',
'            else',
'        apex_util.set_session_state(''SESSION_SEC_QUES_COMPLETE'', ''Y'');',
'     end if;',
'',
'',
'',
'        if lower(:APP_USER) != ''admin'' then ',
'      FOR rec IN (SELECT APEX_SESSION_ID ',
'                   FROM apex_workspace_sessions ',
'                   WHERE user_name = :APP_USER ',
'                   AND APEX_SESSION_ID != :APP_SESSION) ',
'        LOOP',
'            apex_session.delete_session(rec.APEX_SESSION_ID);',
'        END LOOP;',
'     end if;   ',
'',
'     -- APEX_UTIL.SET_SESSION_STATE(''P0_FORCE_PW_CHANGE'', ''Y'');',
'   --  APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:test-page10::::::'');',
'    -- owa_util.redirect_url(''f?p='' || apex_application.g_flow_id || '':89::::::'');',
'    -- apex_application.g_unrecoverable_error := true;',
'',
'    -- APEX_UTIL.REDIRECT_URL(''f?p='' || :APP_ID || '':89:'' || :APP_SESSION);',
'',
'    EXCEPTION',
'    WHEN OTHERS',
'    THEN',
'        APEX_JSON.open_object;',
'        APEX_JSON.write (''message'', ''Error'');',
'        APEX_JSON.close_object;',
'     --   :status := 401;',
'',
'      APEX_APPLICATION.STOP_APEX_ENGINE;',
'            APEX_UTIL.REDIRECT_URL(''f?p='' || :APP_ID || '':89:'' || :APP_SESSION);*/',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>15641262904808
);
wwv_flow_imp.component_end;
end;
/
