prompt --application/shared_components/user_interface/lovs/user_ukkname_lov
begin
--   Manifest
--     USER_UKKNAME_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(67488974837582754255)
,p_lov_name=>'USER_UKKNAME_LOV'
,p_lov_query=>'select FIRSTNAME || '' '' || LASTNAME as FULLNAME , ID from T_USERS'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'FULLNAME'
,p_default_sort_column_name=>'FULLNAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15641582251314
);
wwv_flow_imp.component_end;
end;
/
