prompt --application/shared_components/user_interface/lovs/yesno_char
begin
--   Manifest
--     YESNO_CHAR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(66135643621596401127)
,p_lov_name=>'YESNO_CHAR'
,p_lov_query=>'.'||wwv_flow_imp.id(66135643621596401127)||'.'
,p_location=>'STATIC'
,p_version_scn=>15640494395402
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(66135643914611401129)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'YES'
,p_lov_return_value=>'Y'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(66135644313753401130)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'NO'
,p_lov_return_value=>'N'
);
wwv_flow_imp.component_end;
end;
/
