prompt --application/shared_components/files/style_css
begin
--   Manifest
--     APP STATIC FILES: 166473
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '627574746F6E5B646174612D6F74656C2D6C6162656C3D2244454C455445225D207B0D0A2020202020206261636B67726F756E642D636F6C6F723A207265643B0D0A202020202020636F6C6F723A2077686974653B0D0A202020207D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(67490241460736820899)
,p_file_name=>'style.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
