prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>65948085634457652683
,p_default_application_id=>166473
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SAHAND'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(65949117124087674847)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>15642347681751
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(65949128972339674870)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(65960880821167975702)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'users'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-user'
,p_security_scheme=>wwv_flow_imp.id(66369644599993048366)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2,3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(66368244788054985041)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'roles'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badges'
,p_security_scheme=>wwv_flow_imp.id(66369644599993048366)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5,6'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(68083795605507587104)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'activity log'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-history'
,p_security_scheme=>wwv_flow_imp.id(66369644599993048366)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8,10'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(66138282432378554286)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'change password'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-lock-new'
,p_security_scheme=>wwv_flow_imp.id(66369644599993048366)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_imp.component_end;
end;
/
