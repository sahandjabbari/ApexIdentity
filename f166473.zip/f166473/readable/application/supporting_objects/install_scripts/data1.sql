begin
    --T_USERS: 2/10000 rows exported, APEX$DATA$PKG/T_USERS$411160
    apex_data_install.load_supporting_object_data(p_table_name => 'T_USERS', p_delete_after_install => true );


   update T_USERS set PASSWORD = FN_HASH_PASSWORD(UPPER('admin'), '123456')  where lower(username) = 'admin';
end;